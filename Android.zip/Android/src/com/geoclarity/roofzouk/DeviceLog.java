package com.geoclarity.roofzouk;


public class DeviceLog  {
	
    public int userIdx;
    public String deviceIMEI;
    public String timestamp;
    public double longitude;
    public double latitude;
    public int batteryStatus;
    public String phoneNumber;
    
    public DeviceLog(){}
    
    
}
